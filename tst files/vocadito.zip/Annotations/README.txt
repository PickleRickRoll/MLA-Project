
F0 Annotations
--------------

column 1: evenly spaced timestamps in seconds
column 2: f0 values in Hz. A value of 0.0 indicates that no f0 is present


Lyrics
------

Lyrics are in a text file with each line containing words corresponding to a musical phrase and space separated words within in a line.


Note Annotations
----------------

column 1: note start time in seconds
column 2: note pitch in Hz
column 3: note duration in seconds 

vocadito_*_notesA1.csv : Notes annotated by annotator 1
vocadito_*_notesA2.csv : Notes annotated by annotator 2
